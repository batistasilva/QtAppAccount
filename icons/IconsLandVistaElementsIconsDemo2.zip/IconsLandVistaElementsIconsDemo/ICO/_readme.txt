.ICO files in this Demo icon set are free for personal use.

If you would like to have .ICO files, 
please buy icon set (there will be only .PNG files)
and write email to icons@icons-land.com
Then you'll receive icons in .ICO format.

This limitation is created to reduce size of donwload file.

